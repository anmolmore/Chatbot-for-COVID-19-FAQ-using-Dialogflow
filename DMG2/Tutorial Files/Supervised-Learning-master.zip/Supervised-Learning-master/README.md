# Supervised-Learning

### Linear Discriminant Analysis
### K-Nearest Neighbors
### Decision Trees
### Naive Bayes